package fixtures;

public class Room extends Fixture{
	public Room[] exits = new Room[5];
	
	
	
	private String shortDescription;
	private String longDescription;
	private Fixture[] items;
	
	public Room(String name, String shortDescription, String longDescription) {
		super(name, shortDescription, longDescription);
		this.exits = new Room[5]; //size is your choice
	}
	//room exit getters and setters
	
	public Room[] getExits() {
		return this.exits;
	}
	
	public Room getExit(String direction) {
		return null;
	}
	
	public void setExits(Room[] exits) {
		this.exits = exits;
	}
	
	public void setExits(Room exit, int i) {
		this.getExits()[i] = exit;
	}
	
	public String getName() {
		return name;
	}
	
	public String getShortDescription() {
		return shortDescription;
	}
	
	public String getLongDescription() {
		return longDescription;
	}
	
	///setters and getters for items maybe will use varargs

	public Fixture[] getItems() {
		return items;
	}

	public void setItems(Fixture[] items) {
		this.items = items;
	}
}
