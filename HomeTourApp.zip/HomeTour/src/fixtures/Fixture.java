package fixtures;

public abstract class Fixture {

	
	String name;
	String ShortDescription;
	String longDescription;
	//constructors
	public Fixture(String name, String shortDescription, String longDescription) {
		// TODO Auto-generated constructor stub
	}
	
	
	
	//this is are getters and setters
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getShortDescription() {
		return ShortDescription;
	}
	public void setShortDescription(String shortDescription) {
		ShortDescription = shortDescription;
	}
	public String getLongDescription() {
		return longDescription;
	}
	public void setLongDescription(String longDescription) {
		this.longDescription = longDescription;
	}



	@Override
	public String toString() {
		return "Fixture [name=" + name + ", ShortDescription=" + ShortDescription + ", longDescription="
				+ longDescription + "]";
	}
	
	//tostring
	
	
	
	

}
