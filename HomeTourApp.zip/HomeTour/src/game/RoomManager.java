package game;

import fixtures.Room;
//This class will manage: create the house and provide functions to traverse the house
public class RoomManager {
	
	//first room player will start from (kitchen)
	private Room startingRoom;
	
	///getter and setters
	public Room getStartingRoom() {
		return this.startingRoom;
	}
	
	public void setStartingRoom(Room startingRoom) {
		this.startingRoom = startingRoom;
	}
	
	//creating array of all the rooms
	Room[] rooms = new Room[5];
	
	public RoomManager(int roomCount) {
		super();
		rooms = new Room[roomCount];
	}
	
	public void init() {
		//building a room
		Room room1 = new Room(
				"Kitchen", 
				"Small kitchen:", 
				"The small kitchen has style. Counter Stove, with a small sink");
		this.rooms[0] = room1;
		startingRoom = room1;
		
		Room room2 = new Room(
				"Garage",
				"2 Space Garage",
				"Garage used to store tools and two automobiles. Concrete floor with glossy look.");
		this.rooms[1] = room2;
		
		
		Room room3 = new Room(
				"Small Bedroom",
				"A small bedroom",
				"The room is small with a twin bed and a small tv along with a small closet");
		this.rooms[2] = room3;
		
		Room room4 = new Room(
				"Master Bedroom",
				"A big bedroom",
				"Huge bedroom with direct access to the bathroom and a full size king bed");
		this.rooms[3] = room4;
		
		Room[] room1Exits = new Room[] {room4, room3, null, null};
		
		room1.setExits(room1Exits);
		
		
		
	}
	
	/*/getter and setters
	public Room getStartingRoom() {
		return this.getStartingRoom();
	}
	
	public void setStartingRoom(Room startingRoom) {
		this.startingRoom = startingRoom;
	}
	public Room[] getHouse() {
		return this.house;
	}
	
	public void setHouse(Room[] house) {
		this.house = house;*/
	}

