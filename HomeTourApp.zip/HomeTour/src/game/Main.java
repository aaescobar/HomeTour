package game;
//import
import java.util.Scanner;


public class Main {
	
	//calls in the room manager to start building rooms
	private static RoomManager buildRooms = new RoomManager(5);
	//variable wswitch game
	static boolean turnon = true;
	// call  for player class intantiation
	
	//main method
	public static void main(String[] args) {
		Player player = new Player();
		//start the construction of rooms
		buildRooms.init();
		//location
		player.setCurrentRoom(buildRooms.getStartingRoom());
		//player greet
		System.out.println("Welcome to Andy Escobar Home Tour. Feel like your home!");
		
		while(turnon == true) {
		//	System.out.println("Current location: " + player.getCurrentRoom().getName());
		//  System.out.println("Short Description: " + player.getCurrentRoom().getShortDescription());
		//	System.out.println("Long Description: " + player.getCurrentRoom().getLongDescription());
			Main.printFunction(player);
			String[] input = Main.collectInput();
			Main.parse(input, player);
		}
	}
//printroom
	private static void printFunction(Player player) {
		// TODO Auto-generated method stub
		player.getCurrentRoom();
		
		System.out.println(player.currentRoom.getName() + "\n");
		System.out.println(player.currentRoom.getShortDescription() + "\n");
		System.out.println(player.currentRoom.getLongDescription() + "\n");
		
	}
//collectinput
	private static String[] collectInput() {
		//input request
		Scanner scan = new Scanner(System.in);
		System.out.println("Enter a command and the direction you want to take: North, South, West, East");
		//accept command from player
		String input = scan.nextLine();
		String[] comand = input.split(" ");
		//closing object
		if(turnon == false) {scan.close();}
		return comand;
	}
//parse
	private static void parse(String[] comand, Player player) {
		if(comand[0].equals("End")) {
			turnon = false;
		//move
			
			
		}
		
	}
}
